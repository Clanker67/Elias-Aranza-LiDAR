/**
 * Minimal working example of PCL and ROS 2
 * + Bounding boxes (MarkerArray) from Euclidean clustering
 *
 * UPDATED:
 * - Publish LaserScan (fake_scan) generated from BOUNDING BOX OUTLINES
 * - Keep bounding boxes for RViz visualization
 * - Publish scan in a robot/sensor-centered frame (scan_frame)
 */

#include <rclcpp/qos.hpp>
#include <rclcpp/rclcpp.hpp>

#include <sensor_msgs/msg/point_cloud2.hpp>
#include <sensor_msgs/msg/laser_scan.hpp>
#include <visualization_msgs/msg/marker_array.hpp>
#include <geometry_msgs/msg/point.hpp>

#include <tf2_ros/transform_broadcaster.h>
#include <tf2_ros/transform_listener.h>
#include <tf2_ros/buffer.h>

#include <pcl/common/common.h>
#include <pcl/filters/crop_box.h>
#include <pcl/filters/passthrough.h>
#include <pcl/filters/voxel_grid.h>
#include <pcl/segmentation/extract_clusters.h>
#include <pcl/search/kdtree.h>

#include <pcl_conversions/pcl_conversions.h>
#include <pcl_ros/transforms.hpp>

#include <chrono>
#include <memory>
#include <string>
#include <vector>
#include <sstream>
#include <iomanip>
#include <limits>
#include <cmath>
#include <array>
#include <algorithm>

class MinimalPointCloudProcessor : public rclcpp::Node
{
public:
  MinimalPointCloudProcessor()
  : Node("minimal_point_cloud_processor",
         rclcpp::NodeOptions()
           .allow_undeclared_parameters(true)
           .automatically_declare_parameters_from_overrides(true))
  {
    RCLCPP_INFO(this->get_logger(), "Setting up publishers");

    voxel_grid_pub_ = this->create_publisher<sensor_msgs::msg::PointCloud2>("voxel_cluster", 1);
    lanebox_pub_    = this->create_publisher<sensor_msgs::msg::PointCloud2>("lanebox", 1);
    right_pub_      = this->create_publisher<sensor_msgs::msg::PointCloud2>("rightside", 1);
    left_pub_       = this->create_publisher<sensor_msgs::msg::PointCloud2>("leftside", 1);
    stop_pub_       = this->create_publisher<sensor_msgs::msg::PointCloud2>("stopsign", 1);
    stop_pub_2      = this->create_publisher<sensor_msgs::msg::PointCloud2>("stopsign2", 1);
    around_pub_     = this->create_publisher<sensor_msgs::msg::PointCloud2>("aroundbox", 1);

    bbox_pub_       = this->create_publisher<visualization_msgs::msg::MarkerArray>("bounding_boxes", 10);
    scan_pub_       = this->create_publisher<sensor_msgs::msg::LaserScan>("fake_scan", 10);

    RCLCPP_INFO(this->get_logger(), "Getting parameters");

    rclcpp::Parameter cloud_topic_param, world_frame_param, camera_frame_param, scan_frame_param;
    rclcpp::Parameter voxel_leaf_size_param, x_filter_min_param, x_filter_max_param;
    rclcpp::Parameter y_filter_min_param, y_filter_max_param, z_filter_min_param, z_filter_max_param;
    rclcpp::Parameter cluster_tolerance_param, cluster_min_size_param, cluster_max_size_param;

    this->get_parameter_or("cloud_topic", cloud_topic_param, rclcpp::Parameter("", "/points"));
    this->get_parameter_or("world_frame", world_frame_param, rclcpp::Parameter("", "map"));
    this->get_parameter_or("camera_frame", camera_frame_param, rclcpp::Parameter("", "map"));
    this->get_parameter_or("scan_frame", scan_frame_param, rclcpp::Parameter("", "base_link"));

    // smaller default voxel size for denser scan
    this->get_parameter_or("voxel_leaf_size", voxel_leaf_size_param, rclcpp::Parameter("", 0.08));
    this->get_parameter_or("x_filter_min", x_filter_min_param, rclcpp::Parameter("", 1.0));
    this->get_parameter_or("x_filter_max", x_filter_max_param, rclcpp::Parameter("", 120.0));
    this->get_parameter_or("y_filter_min", y_filter_min_param, rclcpp::Parameter("", -25.0));
    this->get_parameter_or("y_filter_max", y_filter_max_param, rclcpp::Parameter("", 10.0));
    this->get_parameter_or("z_filter_min", z_filter_min_param, rclcpp::Parameter("", -1.0));
    this->get_parameter_or("z_filter_max", z_filter_max_param, rclcpp::Parameter("", 8.0));

    this->get_parameter_or("cluster_tolerance", cluster_tolerance_param, rclcpp::Parameter("", 1.5));
    this->get_parameter_or("cluster_min_size", cluster_min_size_param, rclcpp::Parameter("", 30));
    this->get_parameter_or("cluster_max_size", cluster_max_size_param, rclcpp::Parameter("", 20000));

    cloud_topic     = cloud_topic_param.as_string();
    world_frame     = world_frame_param.as_string();
    camera_frame    = camera_frame_param.as_string();
    scan_frame      = scan_frame_param.as_string();

    voxel_leaf_size = static_cast<float>(voxel_leaf_size_param.as_double());
    x_filter_min    = x_filter_min_param.as_double();
    x_filter_max    = x_filter_max_param.as_double();
    y_filter_min    = y_filter_min_param.as_double();
    y_filter_max    = y_filter_max_param.as_double();
    z_filter_min    = z_filter_min_param.as_double();
    z_filter_max    = z_filter_max_param.as_double();

    cluster_tolerance_ = static_cast<float>(cluster_tolerance_param.as_double());
    cluster_min_size_  = cluster_min_size_param.as_int();
    cluster_max_size_  = cluster_max_size_param.as_int();

    RCLCPP_INFO(this->get_logger(), "Subscribing to: %s", cloud_topic.c_str());
    RCLCPP_INFO(this->get_logger(), "world_frame: %s", world_frame.c_str());
    RCLCPP_INFO(this->get_logger(), "scan_frame: %s", scan_frame.c_str());

    cloud_subscriber_ =
      this->create_subscription<sensor_msgs::msg::PointCloud2>(
        cloud_topic,
        rclcpp::SensorDataQoS(),
        std::bind(&MinimalPointCloudProcessor::cloud_callback, this, std::placeholders::_1));

    tf_buffer_   = std::make_unique<tf2_ros::Buffer>(this->get_clock());
    tf_listener_ = std::make_shared<tf2_ros::TransformListener>(*tf_buffer_);
    br_ = std::make_unique<tf2_ros::TransformBroadcaster>(*this);
  }

private:
  rclcpp::Subscription<sensor_msgs::msg::PointCloud2>::SharedPtr cloud_subscriber_;

  rclcpp::Publisher<sensor_msgs::msg::PointCloud2>::SharedPtr voxel_grid_pub_;
  rclcpp::Publisher<sensor_msgs::msg::PointCloud2>::SharedPtr lanebox_pub_;
  rclcpp::Publisher<sensor_msgs::msg::PointCloud2>::SharedPtr right_pub_;
  rclcpp::Publisher<sensor_msgs::msg::PointCloud2>::SharedPtr left_pub_;
  rclcpp::Publisher<sensor_msgs::msg::PointCloud2>::SharedPtr stop_pub_;
  rclcpp::Publisher<sensor_msgs::msg::PointCloud2>::SharedPtr stop_pub_2;
  rclcpp::Publisher<sensor_msgs::msg::PointCloud2>::SharedPtr around_pub_;
  rclcpp::Publisher<visualization_msgs::msg::MarkerArray>::SharedPtr bbox_pub_;
  rclcpp::Publisher<sensor_msgs::msg::LaserScan>::SharedPtr scan_pub_;

  std::string cloud_topic;
  std::string world_frame;
  std::string camera_frame;
  std::string scan_frame;

  float voxel_leaf_size;
  float x_filter_min, x_filter_max;
  float y_filter_min, y_filter_max;
  float z_filter_min, z_filter_max;

  float cluster_tolerance_;
  int cluster_min_size_;
  int cluster_max_size_;

  std::unique_ptr<tf2_ros::Buffer> tf_buffer_;
  std::shared_ptr<tf2_ros::TransformListener> tf_listener_;
  std::unique_ptr<tf2_ros::TransformBroadcaster> br_;

  struct Box2D
  {
    float min_x, max_x;
    float min_y, max_y;
  };

  void publishPointCloud(
      const rclcpp::Publisher<sensor_msgs::msg::PointCloud2>::SharedPtr& publisher,
      const pcl::PointCloud<pcl::PointXYZI>& point_cloud,
      const std::string& frame_id)
  {
    sensor_msgs::msg::PointCloud2 msg;
    pcl::toROSMsg(point_cloud, msg);
    msg.header.frame_id = frame_id;
    msg.header.stamp = this->get_clock()->now();
    publisher->publish(msg);
  }

  std::vector<Box2D> extractBoxes(
      const pcl::PointCloud<pcl::PointXYZI>::Ptr& cloud) const
  {
    std::vector<Box2D> boxes;

    if (!cloud || cloud->empty())
      return boxes;

    pcl::search::KdTree<pcl::PointXYZI>::Ptr tree(new pcl::search::KdTree<pcl::PointXYZI>());
    tree->setInputCloud(cloud);

    std::vector<pcl::PointIndices> cluster_indices;

    pcl::EuclideanClusterExtraction<pcl::PointXYZI> ec;
    ec.setClusterTolerance(cluster_tolerance_);
    ec.setMinClusterSize(cluster_min_size_);
    ec.setMaxClusterSize(cluster_max_size_);
    ec.setSearchMethod(tree);
    ec.setInputCloud(cloud);
    ec.extract(cluster_indices);

    for (const auto& indices : cluster_indices)
    {
      pcl::PointCloud<pcl::PointXYZI> cluster;
      cluster.reserve(indices.indices.size());

      for (int idx : indices.indices)
        cluster.push_back((*cloud)[idx]);

      pcl::PointXYZI min_pt, max_pt;
      pcl::getMinMax3D(cluster, min_pt, max_pt);

      Box2D b;
      b.min_x = min_pt.x;
      b.max_x = max_pt.x;
      b.min_y = min_pt.y;
      b.max_y = max_pt.y;
      boxes.push_back(b);
    }

    return boxes;
  }

  bool raySegmentIntersection(
      float ray_dx, float ray_dy,
      float x1, float y1,
      float x2, float y2,
      float& out_t) const
  {
    const float sx = x2 - x1;
    const float sy = y2 - y1;

    const float denom = ray_dx * sy - ray_dy * sx;

    if (std::fabs(denom) < 1e-6f)
      return false;

    const float qpx = x1;
    const float qpy = y1;

    const float t = (qpx * sy - qpy * sx) / denom;
    const float u = (qpx * ray_dy - qpy * ray_dx) / denom;

    if (t >= 0.0f && u >= 0.0f && u <= 1.0f)
    {
      out_t = t;  // ray direction is unit length
      return true;
    }

    return false;
  }

  sensor_msgs::msg::LaserScan boxesToScan(
      const std::vector<Box2D>& boxes,
      const std_msgs::msg::Header& header) const
  {
    sensor_msgs::msg::LaserScan scan;
    scan.header = header;

    scan.angle_min = -static_cast<float>(M_PI);
    scan.angle_max =  static_cast<float>(M_PI);
    scan.angle_increment = 0.00436f;  // ~0.25 deg
    scan.range_min = 0.10f;
    scan.range_max = 30.0f;

    const int beam_count =
      static_cast<int>(std::floor((scan.angle_max - scan.angle_min) / scan.angle_increment)) + 1;

    scan.ranges.assign(beam_count, scan.range_max);
    scan.intensities.assign(beam_count, 100.0f);

    for (int i = 0; i < beam_count; ++i)
    {
      const float angle = scan.angle_min + i * scan.angle_increment;
      const float dx = std::cos(angle);
      const float dy = std::sin(angle);

      float best_range = scan.range_max;

      for (const auto& b : boxes)
      {
        const std::array<std::array<float, 4>, 4> edges = {{
          {b.min_x, b.min_y, b.max_x, b.min_y},
          {b.max_x, b.min_y, b.max_x, b.max_y},
          {b.max_x, b.max_y, b.min_x, b.max_y},
          {b.min_x, b.max_y, b.min_x, b.min_y}
        }};

        for (const auto& e : edges)
        {
          float t;
          if (raySegmentIntersection(dx, dy, e[0], e[1], e[2], e[3], t))
          {
            if (t >= scan.range_min && t <= scan.range_max)
              best_range = std::min(best_range, t);
          }
        }
      }

      scan.ranges[i] = best_range;
    }

    return scan;
  }

  std::vector<Box2D> publishBoundingBoxes(
      const pcl::PointCloud<pcl::PointXYZI>::Ptr& cloud,
      const std_msgs::msg::Header& header)
  {
    visualization_msgs::msg::MarkerArray marker_array;
    std::vector<Box2D> boxes;

    if (!cloud || cloud->empty())
    {
      bbox_pub_->publish(marker_array);
      return boxes;
    }

    pcl::search::KdTree<pcl::PointXYZI>::Ptr tree(new pcl::search::KdTree<pcl::PointXYZI>());
    tree->setInputCloud(cloud);

    std::vector<pcl::PointIndices> cluster_indices;

    pcl::EuclideanClusterExtraction<pcl::PointXYZI> ec;
    ec.setClusterTolerance(cluster_tolerance_);
    ec.setMinClusterSize(cluster_min_size_);
    ec.setMaxClusterSize(cluster_max_size_);
    ec.setSearchMethod(tree);
    ec.setInputCloud(cloud);
    ec.extract(cluster_indices);

    int id = 0;

    for (const auto& indices : cluster_indices)
    {
      pcl::PointCloud<pcl::PointXYZI> cluster;
      cluster.reserve(indices.indices.size());

      for (int idx : indices.indices)
        cluster.push_back((*cloud)[idx]);

      pcl::PointXYZI min_pt, max_pt;
      pcl::getMinMax3D(cluster, min_pt, max_pt);

      const float dx = std::max(0.01f, (max_pt.x - min_pt.x));
      const float dy = std::max(0.01f, (max_pt.y - min_pt.y));
      const float dz = std::max(0.01f, (max_pt.z - min_pt.z));

      Box2D b;
      b.min_x = min_pt.x;  b.max_x = max_pt.x;
      b.min_y = min_pt.y;  b.max_y = max_pt.y;
      boxes.push_back(b);

      const float z_floor = min_pt.z;

      visualization_msgs::msg::Marker outline;
      outline.header = header;
      outline.ns = "bbox_2d_outline";
      outline.id = id++;
      outline.type = visualization_msgs::msg::Marker::LINE_STRIP;
      outline.action = visualization_msgs::msg::Marker::ADD;
      outline.pose.orientation.w = 1.0;
      outline.scale.x = 0.06;
      outline.color.a = 1.0;
      outline.color.r = 0.0;
      outline.color.g = 1.0;
      outline.color.b = 0.0;

      geometry_msgs::msg::Point p;
      p.x = min_pt.x; p.y = min_pt.y; p.z = z_floor; outline.points.push_back(p);
      p.x = max_pt.x; p.y = min_pt.y; p.z = z_floor; outline.points.push_back(p);
      p.x = max_pt.x; p.y = max_pt.y; p.z = z_floor; outline.points.push_back(p);
      p.x = min_pt.x; p.y = max_pt.y; p.z = z_floor; outline.points.push_back(p);
      p.x = min_pt.x; p.y = min_pt.y; p.z = z_floor; outline.points.push_back(p);

      outline.lifetime.sec = 0;
      outline.lifetime.nanosec = 200'000'000;
      marker_array.markers.push_back(outline);

      visualization_msgs::msg::Marker label;
      label.header = header;
      label.ns = "bbox_height";
      label.id = id++;
      label.type = visualization_msgs::msg::Marker::TEXT_VIEW_FACING;
      label.action = visualization_msgs::msg::Marker::ADD;
      label.pose.position.x = (min_pt.x + max_pt.x) * 0.5f;
      label.pose.position.y = (min_pt.y + max_pt.y) * 0.5f;
      label.pose.position.z = z_floor + 0.25f;
      label.pose.orientation.w = 1.0;
      label.scale.z = 0.35f;
      label.color.a = 1.0f;
      label.color.r = 1.0f;
      label.color.g = 1.0f;
      label.color.b = 1.0f;

      std::ostringstream ss;
      ss << std::fixed << std::setprecision(2)
         << "W:" << dy << "  L:" << dx << "  H:" << dz;

      label.text = ss.str();
      label.lifetime.sec = 0;
      label.lifetime.nanosec = 200'000'000;
      marker_array.markers.push_back(label);
    }

    bbox_pub_->publish(marker_array);
    return boxes;
  }

  void cloud_callback(const sensor_msgs::msg::PointCloud2::ConstSharedPtr recent_cloud)
  {
    auto start = std::chrono::high_resolution_clock::now();

    // -----------------------------
    // Transform 1: world frame for boxes / visualization
    // -----------------------------
    geometry_msgs::msg::TransformStamped world_transform;
    try
    {
      world_transform = tf_buffer_->lookupTransform(
        world_frame,
        recent_cloud->header.frame_id,
        tf2::TimePointZero,
        tf2::durationFromSec(3));
    }
    catch (const tf2::TransformException &ex)
    {
      RCLCPP_ERROR(this->get_logger(), "World transform error: %s", ex.what());
      return;
    }

    sensor_msgs::msg::PointCloud2 world_cloud_msg;
    pcl_ros::transformPointCloud(world_frame, world_transform, *recent_cloud, world_cloud_msg);

    pcl::PointCloud<pcl::PointXYZI> world_cloud;
    pcl::fromROSMsg(world_cloud_msg, world_cloud);

    pcl::PointCloud<pcl::PointXYZI>::Ptr world_cloud_ptr(new pcl::PointCloud<pcl::PointXYZI>(world_cloud));
    pcl::PointCloud<pcl::PointXYZI>::Ptr world_cloud_voxel_filtered(new pcl::PointCloud<pcl::PointXYZI>());
    pcl::VoxelGrid<pcl::PointXYZI> voxel_filter_world;
    voxel_filter_world.setInputCloud(world_cloud_ptr);
    voxel_filter_world.setLeafSize(voxel_leaf_size, voxel_leaf_size, voxel_leaf_size);
    voxel_filter_world.filter(*world_cloud_voxel_filtered);

    pcl::PointCloud<pcl::PointXYZI> around_xyz_filtered_cloud;
    pcl::CropBox<pcl::PointXYZI> crop_all;
    crop_all.setInputCloud(world_cloud_voxel_filtered);
    crop_all.setMin(Eigen::Vector4f(-3.0f, -4.5f, -2.0f, 0.0f));
    crop_all.setMax(Eigen::Vector4f( 3.0f,  4.5f,  3.0f, 0.0f));
    crop_all.filter(around_xyz_filtered_cloud);

    pcl::PointCloud<pcl::PointXYZI> xyz_filtered_cloud;
    pcl::CropBox<pcl::PointXYZI> crop;
    crop.setInputCloud(world_cloud_voxel_filtered);
    crop.setMin(Eigen::Vector4f(x_filter_min, y_filter_min, z_filter_min, 0.0f));
    crop.setMax(Eigen::Vector4f(x_filter_max, y_filter_max, z_filter_max, 0.0f));
    crop.filter(xyz_filtered_cloud);

    pcl::PointCloud<pcl::PointXYZI> right_xyz_filtered_cloud;
    pcl::CropBox<pcl::PointXYZI> cropr;
    cropr.setInputCloud(world_cloud_voxel_filtered);
    cropr.setMin(Eigen::Vector4f(0, -10, -15, 0));
    cropr.setMax(Eigen::Vector4f(10, 10, 15, 0));
    cropr.filter(right_xyz_filtered_cloud);

    pcl::PointCloud<pcl::PointXYZI> left_xyz_filtered_cloud;
    pcl::CropBox<pcl::PointXYZI> cropl;
    cropl.setInputCloud(world_cloud_voxel_filtered);
    cropl.setMin(Eigen::Vector4f(-10, -10, -15, 0));
    cropl.setMax(Eigen::Vector4f(0, 10, 15, 0));
    cropl.filter(left_xyz_filtered_cloud);

    pcl::PointCloud<pcl::PointXYZI> stop_xyz_filtered_cloud;
    pcl::CropBox<pcl::PointXYZI> crops;
    crops.setInputCloud(world_cloud_voxel_filtered);
    crops.setMin(Eigen::Vector4f(0, 0, -15, 0));
    crops.setMax(Eigen::Vector4f(10, 10, 15, 0));
    crops.filter(stop_xyz_filtered_cloud);

    pcl::PointCloud<pcl::PointXYZI> stop2_xyz_filtered_cloud;
    pcl::PassThrough<pcl::PointXYZI> passs;
    passs.setInputCloud(stop_xyz_filtered_cloud.makeShared());
    passs.setFilterFieldName("intensity");
    passs.setFilterLimits(4500, 50000);
    passs.filter(stop2_xyz_filtered_cloud);

    // publish visualization clouds in world frame
    publishPointCloud(voxel_grid_pub_, *world_cloud_voxel_filtered, world_frame);
    publishPointCloud(lanebox_pub_, xyz_filtered_cloud, world_frame);
    publishPointCloud(right_pub_, right_xyz_filtered_cloud, world_frame);
    publishPointCloud(left_pub_, left_xyz_filtered_cloud, world_frame);
    publishPointCloud(stop_pub_, stop_xyz_filtered_cloud, world_frame);
    publishPointCloud(stop_pub_2, stop2_xyz_filtered_cloud, world_frame);
    publishPointCloud(around_pub_, around_xyz_filtered_cloud, world_frame);

    std_msgs::msg::Header world_hdr;
    world_hdr.frame_id = world_frame;
    world_hdr.stamp = this->get_clock()->now();

    auto world_boxes = publishBoundingBoxes(around_xyz_filtered_cloud.makeShared(), world_hdr);

    // -----------------------------
    // Transform 2: scan frame for LaserScan
    // -----------------------------
    geometry_msgs::msg::TransformStamped scan_transform;
    try
    {
      scan_transform = tf_buffer_->lookupTransform(
        scan_frame,
        recent_cloud->header.frame_id,
        tf2::TimePointZero,
        tf2::durationFromSec(3));
    }
    catch (const tf2::TransformException &ex)
    {
      RCLCPP_ERROR(this->get_logger(), "Scan transform error: %s", ex.what());
      return;
    }

    sensor_msgs::msg::PointCloud2 scan_cloud_msg_ros;
    pcl_ros::transformPointCloud(scan_frame, scan_transform, *recent_cloud, scan_cloud_msg_ros);

    pcl::PointCloud<pcl::PointXYZI> scan_cloud_raw;
    pcl::fromROSMsg(scan_cloud_msg_ros, scan_cloud_raw);

    pcl::PointCloud<pcl::PointXYZI>::Ptr scan_cloud_ptr(new pcl::PointCloud<pcl::PointXYZI>(scan_cloud_raw));
    pcl::PointCloud<pcl::PointXYZI>::Ptr scan_cloud_voxel_filtered(new pcl::PointCloud<pcl::PointXYZI>());
    pcl::VoxelGrid<pcl::PointXYZI> voxel_filter_scan;
    voxel_filter_scan.setInputCloud(scan_cloud_ptr);
    voxel_filter_scan.setLeafSize(voxel_leaf_size, voxel_leaf_size, voxel_leaf_size);
    voxel_filter_scan.filter(*scan_cloud_voxel_filtered);

    pcl::PointCloud<pcl::PointXYZI> scan_filtered_cloud;
    pcl::CropBox<pcl::PointXYZI> scan_crop;
    scan_crop.setInputCloud(scan_cloud_voxel_filtered);
    scan_crop.setMin(Eigen::Vector4f(-6.0f, -6.0f, -1.0f, 0.0f));
    scan_crop.setMax(Eigen::Vector4f( 6.0f,  6.0f,  1.5f, 0.0f));
    scan_crop.filter(scan_filtered_cloud);

    std_msgs::msg::Header scan_hdr;
    scan_hdr.frame_id = scan_frame;
    scan_hdr.stamp = this->get_clock()->now();

    auto scan_boxes = extractBoxes(scan_filtered_cloud.makeShared());
    auto scan_msg = boxesToScan(scan_boxes, scan_hdr);
    scan_pub_->publish(scan_msg);

    auto stop = std::chrono::high_resolution_clock::now();
    auto t_ms = std::chrono::duration_cast<std::chrono::milliseconds>(stop - start);
    RCLCPP_INFO(this->get_logger(),
                "Time (msec): %ld | world clusters: %zu | scan clusters: %zu | lane pts: %zu | around pts: %zu | voxel pts: %zu | scan pts: %zu",
                t_ms.count(), world_boxes.size(), scan_boxes.size(),
                xyz_filtered_cloud.size(), around_xyz_filtered_cloud.size(),
                world_cloud_voxel_filtered->size(), scan_filtered_cloud.size());
  }
};

int main(int argc, char* argv[])
{
  rclcpp::init(argc, argv);
  auto node = std::make_shared<MinimalPointCloudProcessor>();
  rclcpp::spin(node);
  rclcpp::shutdown();
  return 0;
}
