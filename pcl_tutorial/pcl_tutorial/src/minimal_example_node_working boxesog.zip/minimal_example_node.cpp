/**
 * Minimal working example of PCL and ROS 2
 * + Bounding boxes (MarkerArray) from Euclidean clustering
 */

#include <rclcpp/qos.hpp>
#include <rclcpp/rclcpp.hpp>

#include <sensor_msgs/msg/point_cloud2.hpp>
#include <visualization_msgs/msg/marker_array.hpp>

#include <tf2_ros/transform_broadcaster.h>
#include <tf2_ros/transform_listener.h>
#include <tf2_ros/buffer.h>

#include <pcl/common/common.h>
#include <pcl/filters/crop_box.h>
#include <pcl/filters/passthrough.h>
#include <pcl/filters/voxel_grid.h>
#include <pcl/segmentation/extract_clusters.h>
#include <pcl/search/kdtree.h>

#include <pcl_conversions/pcl_conversions.h>
#include <pcl_ros/transforms.hpp>

#include <chrono>
#include <memory>
#include <string>
#include <vector>

class MinimalPointCloudProcessor : public rclcpp::Node
{
public:
  MinimalPointCloudProcessor()
  : Node("minimal_point_cloud_processor",
         rclcpp::NodeOptions()
           .allow_undeclared_parameters(true)
           .automatically_declare_parameters_from_overrides(true))
  {
    RCLCPP_INFO(this->get_logger(), "Setting up publishers");

    voxel_grid_pub_ = this->create_publisher<sensor_msgs::msg::PointCloud2>("voxel_cluster", 1);
    lanebox_pub_    = this->create_publisher<sensor_msgs::msg::PointCloud2>("lanebox", 1);
    right_pub_      = this->create_publisher<sensor_msgs::msg::PointCloud2>("rightside", 1);
    left_pub_       = this->create_publisher<sensor_msgs::msg::PointCloud2>("leftside", 1);
    stop_pub_       = this->create_publisher<sensor_msgs::msg::PointCloud2>("stopsign", 1);
    stop_pub_2      = this->create_publisher<sensor_msgs::msg::PointCloud2>("stopsign2", 1);

    // ✅ bounding boxes output (RViz MarkerArray)
    bbox_pub_       = this->create_publisher<visualization_msgs::msg::MarkerArray>("bounding_boxes", 10);

    RCLCPP_INFO(this->get_logger(), "Getting parameters");

    rclcpp::Parameter cloud_topic_param, world_frame_param, camera_frame_param, voxel_leaf_size_param,
      x_filter_min_param, x_filter_max_param, y_filter_min_param, y_filter_max_param, z_filter_min_param,
      z_filter_max_param;

    // clustering params
    rclcpp::Parameter cluster_tolerance_param, cluster_min_size_param, cluster_max_size_param;

    this->get_parameter_or("cloud_topic", cloud_topic_param, rclcpp::Parameter("", "/points"));
    this->get_parameter_or("world_frame", world_frame_param, rclcpp::Parameter("", "laser_data_frame"));
    this->get_parameter_or("camera_frame", camera_frame_param, rclcpp::Parameter("", "laser_data_frame"));

    this->get_parameter_or("voxel_leaf_size", voxel_leaf_size_param, rclcpp::Parameter("", 0.25));
    this->get_parameter_or("x_filter_min", x_filter_min_param, rclcpp::Parameter("", 1.0));
    this->get_parameter_or("x_filter_max", x_filter_max_param, rclcpp::Parameter("", 120.0));
    this->get_parameter_or("y_filter_min", y_filter_min_param, rclcpp::Parameter("", -25.0));
    this->get_parameter_or("y_filter_max", y_filter_max_param, rclcpp::Parameter("", 10.0));
    this->get_parameter_or("z_filter_min", z_filter_min_param, rclcpp::Parameter("", -1.0));
    this->get_parameter_or("z_filter_max", z_filter_max_param, rclcpp::Parameter("", 8.0));

    // ✅ Euclidean clustering defaults (you can override via launch parameters)
    this->get_parameter_or("cluster_tolerance", cluster_tolerance_param, rclcpp::Parameter("", 1.5));
    this->get_parameter_or("cluster_min_size", cluster_min_size_param, rclcpp::Parameter("", 30));
    this->get_parameter_or("cluster_max_size", cluster_max_size_param, rclcpp::Parameter("", 20000));

    cloud_topic     = cloud_topic_param.as_string();
    world_frame     = world_frame_param.as_string();
    camera_frame    = camera_frame_param.as_string();

    voxel_leaf_size = static_cast<float>(voxel_leaf_size_param.as_double());
    x_filter_min    = x_filter_min_param.as_double();
    x_filter_max    = x_filter_max_param.as_double();
    y_filter_min    = y_filter_min_param.as_double();
    y_filter_max    = y_filter_max_param.as_double();
    z_filter_min    = z_filter_min_param.as_double();
    z_filter_max    = z_filter_max_param.as_double();

    cluster_tolerance_ = static_cast<float>(cluster_tolerance_param.as_double());
    cluster_min_size_  = cluster_min_size_param.as_int();
    cluster_max_size_  = cluster_max_size_param.as_int();

    RCLCPP_INFO(this->get_logger(), "Subscribing to: %s", cloud_topic.c_str());
    RCLCPP_INFO(this->get_logger(), "world_frame: %s", world_frame.c_str());

    cloud_subscriber_ =
      this->create_subscription<sensor_msgs::msg::PointCloud2>(
        cloud_topic,
        rclcpp::SensorDataQoS(),
        std::bind(&MinimalPointCloudProcessor::cloud_callback, this, std::placeholders::_1));

    // TF (unchanged)
    tf_buffer_   = std::make_unique<tf2_ros::Buffer>(this->get_clock());
    tf_listener_ = std::make_shared<tf2_ros::TransformListener>(*tf_buffer_);
    br_ = std::make_unique<tf2_ros::TransformBroadcaster>(*this);
  }

private:
  // Sub/Pubs
  rclcpp::Subscription<sensor_msgs::msg::PointCloud2>::SharedPtr cloud_subscriber_;

  rclcpp::Publisher<sensor_msgs::msg::PointCloud2>::SharedPtr voxel_grid_pub_;
  rclcpp::Publisher<sensor_msgs::msg::PointCloud2>::SharedPtr lanebox_pub_;
  rclcpp::Publisher<sensor_msgs::msg::PointCloud2>::SharedPtr right_pub_;
  rclcpp::Publisher<sensor_msgs::msg::PointCloud2>::SharedPtr left_pub_;
  rclcpp::Publisher<sensor_msgs::msg::PointCloud2>::SharedPtr stop_pub_;
  rclcpp::Publisher<sensor_msgs::msg::PointCloud2>::SharedPtr stop_pub_2;

  rclcpp::Publisher<visualization_msgs::msg::MarkerArray>::SharedPtr bbox_pub_;

  // Params
  std::string cloud_topic;
  std::string world_frame;
  std::string camera_frame;

  float voxel_leaf_size;
  float x_filter_min, x_filter_max;
  float y_filter_min, y_filter_max;
  float z_filter_min, z_filter_max;

  float cluster_tolerance_;
  int cluster_min_size_;
  int cluster_max_size_;

  // TF
  std::unique_ptr<tf2_ros::Buffer> tf_buffer_;
  std::shared_ptr<tf2_ros::TransformListener> tf_listener_;
  std::unique_ptr<tf2_ros::TransformBroadcaster> br_;

  void publishPointCloud(const rclcpp::Publisher<sensor_msgs::msg::PointCloud2>::SharedPtr& publisher,
                         const pcl::PointCloud<pcl::PointXYZI>& point_cloud)
  {
    sensor_msgs::msg::PointCloud2 msg;
    pcl::toROSMsg(point_cloud, msg);
    msg.header.frame_id = world_frame;
    msg.header.stamp = this->get_clock()->now();
    publisher->publish(msg);
  }

  void publishBoundingBoxes(const pcl::PointCloud<pcl::PointXYZI>::Ptr& cloud,
                            const std_msgs::msg::Header& header)
  {
    visualization_msgs::msg::MarkerArray marker_array;

    if (!cloud || cloud->empty())
    {
      // still publish empty array so RViz clears
      bbox_pub_->publish(marker_array);
      return;
    }

    pcl::search::KdTree<pcl::PointXYZI>::Ptr tree(new pcl::search::KdTree<pcl::PointXYZI>());
    tree->setInputCloud(cloud);

    std::vector<pcl::PointIndices> cluster_indices;
    pcl::EuclideanClusterExtraction<pcl::PointXYZI> ec;
    ec.setClusterTolerance(cluster_tolerance_);
    ec.setMinClusterSize(cluster_min_size_);
    ec.setMaxClusterSize(cluster_max_size_);
    ec.setSearchMethod(tree);
    ec.setInputCloud(cloud);
    ec.extract(cluster_indices);

    int id = 0;
    for (const auto& indices : cluster_indices)
    {
      pcl::PointCloud<pcl::PointXYZI> cluster;
      cluster.reserve(indices.indices.size());
      for (int idx : indices.indices)
      {
        cluster.push_back((*cloud)[idx]);
      }

      pcl::PointXYZI min_pt, max_pt;
      pcl::getMinMax3D(cluster, min_pt, max_pt);

      // Create a cube marker for the AABB
      visualization_msgs::msg::Marker m;
      m.header = header;                 // uses world_frame in callback
      m.ns = "bbox";
      m.id = id++;
      m.type = visualization_msgs::msg::Marker::CUBE;
      m.action = visualization_msgs::msg::Marker::ADD;

      // center
      m.pose.position.x = (min_pt.x + max_pt.x) * 0.5;
      m.pose.position.y = (min_pt.y + max_pt.y) * 0.5;
      m.pose.position.z = (min_pt.z + max_pt.z) * 0.5;

      // orientation identity (axis-aligned box)
      m.pose.orientation.w = 1.0;

      // size
      m.scale.x = std::max(0.01f, (max_pt.x - min_pt.x));
      m.scale.y = std::max(0.01f, (max_pt.y - min_pt.y));
      m.scale.z = std::max(0.01f, (max_pt.z - min_pt.z));

      // color
      m.color.a = 0.35f;
      m.color.r = 1.0f;
      m.color.g = 0.0f;
      m.color.b = 1.0f;

      // lifetime (so they update smoothly)
      m.lifetime.sec = 0;
      m.lifetime.nanosec = 200'000'000;

      marker_array.markers.push_back(m);
    }

    bbox_pub_->publish(marker_array);
  }

  void cloud_callback(const sensor_msgs::msg::PointCloud2::ConstSharedPtr recent_cloud)
  {
    auto start = std::chrono::high_resolution_clock::now();

    // Transform to world frame (unchanged)
    geometry_msgs::msg::TransformStamped stransform;
    try
    {
      stransform = tf_buffer_->lookupTransform(
        world_frame,
        recent_cloud->header.frame_id,
        tf2::TimePointZero,
        tf2::durationFromSec(3));
    }
    catch (const tf2::TransformException &ex)
    {
      RCLCPP_ERROR(this->get_logger(), "%s", ex.what());
      return;
    }

    sensor_msgs::msg::PointCloud2 transformed_cloud;
    pcl_ros::transformPointCloud(world_frame, stransform, *recent_cloud, transformed_cloud);

    // Convert ROS -> PCL
    pcl::PointCloud<pcl::PointXYZI> cloud;
    pcl::fromROSMsg(transformed_cloud, cloud);

    // Voxel grid
    pcl::PointCloud<pcl::PointXYZI>::Ptr cloud_ptr(new pcl::PointCloud<pcl::PointXYZI>(cloud));
    pcl::PointCloud<pcl::PointXYZI>::Ptr cloud_voxel_filtered(new pcl::PointCloud<pcl::PointXYZI>());
    pcl::VoxelGrid<pcl::PointXYZI> voxel_filter;
    voxel_filter.setInputCloud(cloud_ptr);
    voxel_filter.setLeafSize(voxel_leaf_size, voxel_leaf_size, voxel_leaf_size);
    voxel_filter.filter(*cloud_voxel_filtered);

    // Crop lane box (same idea as your code)
    pcl::PointCloud<pcl::PointXYZI> xyz_filtered_cloud;
    pcl::CropBox<pcl::PointXYZI> crop;
    crop.setInputCloud(cloud_voxel_filtered);
    Eigen::Vector4f min_point(x_filter_min, y_filter_min, z_filter_min, 0.0f);
    Eigen::Vector4f max_point(x_filter_max, y_filter_max, z_filter_max, 0.0f);
    crop.setMin(min_point);
    crop.setMax(max_point);
    crop.filter(xyz_filtered_cloud);

    // Other crops (same as your code)
    pcl::PointCloud<pcl::PointXYZI> right_xyz_filtered_cloud;
    pcl::CropBox<pcl::PointXYZI> cropr;
    cropr.setInputCloud(cloud_voxel_filtered);
    cropr.setMin(Eigen::Vector4f(0, -10, -15, 0));
    cropr.setMax(Eigen::Vector4f(10, 10, 15, 0));
    cropr.filter(right_xyz_filtered_cloud);

    pcl::PointCloud<pcl::PointXYZI> left_xyz_filtered_cloud;
    pcl::CropBox<pcl::PointXYZI> cropl;
    cropl.setInputCloud(cloud_voxel_filtered);
    cropl.setMin(Eigen::Vector4f(-10, -10, -15, 0));
    cropl.setMax(Eigen::Vector4f(0, 10, 15, 0));
    cropl.filter(left_xyz_filtered_cloud);

    pcl::PointCloud<pcl::PointXYZI> stop_xyz_filtered_cloud;
    pcl::CropBox<pcl::PointXYZI> crops;
    crops.setInputCloud(cloud_voxel_filtered);
    crops.setMin(Eigen::Vector4f(0, 0, -15, 0));
    crops.setMax(Eigen::Vector4f(10, 10, 15, 0));
    crops.filter(stop_xyz_filtered_cloud);

    pcl::PointCloud<pcl::PointXYZI> stop2_xyz_filtered_cloud;
    pcl::PassThrough<pcl::PointXYZI> passs;
    passs.setInputCloud(stop_xyz_filtered_cloud.makeShared());
    passs.setFilterFieldName("intensity");
    passs.setFilterLimits(4500, 50000);
    passs.filter(stop2_xyz_filtered_cloud);

    // Publish clouds (same as your code)
    publishPointCloud(voxel_grid_pub_, *cloud_voxel_filtered);
    publishPointCloud(lanebox_pub_, xyz_filtered_cloud);
    publishPointCloud(right_pub_, right_xyz_filtered_cloud);
    publishPointCloud(left_pub_, left_xyz_filtered_cloud);
    publishPointCloud(stop_pub_, stop_xyz_filtered_cloud);
    publishPointCloud(stop_pub_2, stop2_xyz_filtered_cloud);

    // ✅ Bounding boxes: cluster on the lane-box cropped cloud
    // (change to right/left/etc if you want)
    auto lane_ptr = xyz_filtered_cloud.makeShared();

    std_msgs::msg::Header hdr;
    hdr.frame_id = world_frame;
    hdr.stamp = this->get_clock()->now();

    publishBoundingBoxes(lane_ptr, hdr);

    auto stop = std::chrono::high_resolution_clock::now();
    auto t_ms = std::chrono::duration_cast<std::chrono::milliseconds>(stop - start);
    RCLCPP_INFO(this->get_logger(), "Time (msec): %ld | lane pts: %zu | voxel pts: %zu",
                t_ms.count(), xyz_filtered_cloud.size(), cloud_voxel_filtered->size());
  }
};

int main(int argc, char* argv[])
{
  rclcpp::init(argc, argv);
  auto node = std::make_shared<MinimalPointCloudProcessor>();
  rclcpp::spin(node);
  rclcpp::shutdown();
  return 0;
}

