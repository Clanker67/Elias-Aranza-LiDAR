from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        Node(
            package='pcl_tutorial',
            executable='minimal_pcl_tutorial',
            name='minimal_example_node',
            # prefix='valgrind --leak-check=yes ',      # Uncomment to run valgrind 
            output='screen',
            parameters=[
                {"cloud_topic": "/ouster/points"},
                {"world_frame": "map"},
                {"camera_frame": "os_lidar"},
                {"voxel_leaf_size": 0.25},          # Size in meters of voxel grid filter
                {"x_filter_min": -1.5},              # Dimensions in meters to crop point cloud
                {"x_filter_max": 1.5},
                {"y_filter_min": 1.0},
                {"y_filter_max": 25.0},
                {"z_filter_min": -15.0},
                {"z_filter_max": 15.0},
                {"plane_max_iterations": 100.0},      # RANSAC max iteration value
                {"plane_distance_threshold": 0.04},  # in meters
                {"cluster_tolerance": .3},         # in meters
                {"cluster_min_size": 2},            # number of points
                {"cluster_max_size": 50}
            ]
        )
     ])
